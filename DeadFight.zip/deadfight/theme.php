<?php

if(!defined("MCR")){ exit("Hacking Attempt!"); }

$theme = array(
	"ThemeName" => "DeadFight",
	"Author" => "Toster, ReyCODE",
	"AuthorUrl" => "https://vk.com/blognrey, https://vk.com/qexyorg",
	"About" => "Шаблон для WebMCR Reloaded, основанный на шаблоне Bootstrap 4 (Alpha 2) от великого и всемогущего @qexyorg. Думаю, он будет не против, ведь сайтов на WebMCR становится больше, и это не может радовать разработчиков :)",
	"Version" => "1.0 [WebMCR Reloaded 1.4.2]"
);

?>